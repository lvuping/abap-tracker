#!/usr/bin/env python3
"""Find all actual pattern locations in ABAP file"""

import re

# Read the ABAP file
with open('input/all_abap_patterns.abap', 'r') as f:
    lines = f.readlines()

# Track all INSERT, UPDATE, MODIFY statements
patterns = {
    'INSERT': [],
    'UPDATE': [],
    'MODIFY': []
}

for i, line in enumerate(lines, 1):
    line_clean = line.strip().upper()

    # Skip comments
    if line_clean.startswith('*'):
        continue

    # Find INSERT statements
    if line_clean.startswith('INSERT '):
        # Find end of statement
        end_line = i
        for j in range(i-1, min(i+20, len(lines))):
            if lines[j].strip().endswith('.'):
                end_line = j + 1
                break
        patterns['INSERT'].append((i, end_line, line.strip()[:60]))

    # Find UPDATE statements
    elif line_clean.startswith('UPDATE '):
        end_line = i
        for j in range(i-1, min(i+20, len(lines))):
            if lines[j].strip().endswith('.'):
                end_line = j + 1
                break
        patterns['UPDATE'].append((i, end_line, line.strip()[:60]))

    # Find MODIFY statements
    elif line_clean.startswith('MODIFY '):
        end_line = i
        for j in range(i-1, min(i+20, len(lines))):
            if lines[j].strip().endswith('.'):
                end_line = j + 1
                break
        patterns['MODIFY'].append((i, end_line, line.strip()[:60]))

# Print all patterns found
print("INSERT Patterns Found:")
print("=" * 70)
for idx, (start, end, snippet) in enumerate(patterns['INSERT'], 1):
    print(f"INSERT #{idx}: Lines {start}-{end}: {snippet}")

print("\nUPDATE Patterns Found:")
print("=" * 70)
for idx, (start, end, snippet) in enumerate(patterns['UPDATE'], 1):
    print(f"UPDATE #{idx}: Lines {start}-{end}: {snippet}")

print("\nMODIFY Patterns Found:")
print("=" * 70)
for idx, (start, end, snippet) in enumerate(patterns['MODIFY'], 1):
    print(f"MODIFY #{idx}: Lines {start}-{end}: {snippet}")

# Now let's also look for patterns with sy-uname
print("\n\nPatterns with sy-uname:")
print("=" * 70)

for i, line in enumerate(lines, 1):
    if 'sy-uname' in line.lower() and not line.strip().startswith('*'):
        print(f"Line {i}: {line.strip()[:80]}")