#!/usr/bin/env python3
"""Test T15 specifically to debug the issue"""

from src.core.db_handler import CompleteDBHandler

# Load the actual file
with open('input/all_abap_patterns.abap', 'r') as f:
    lines = f.readlines()

handler = CompleteDBHandler()

# T15 test case: lines 202-208 (1-based), so 201-208 (0-based)
start_idx = 201  # 0-based
end_idx = 208    # 0-based exclusive

print("Testing T15: UPDATE FROM structure")
print("=" * 60)
print(f"Analyzing lines {start_idx+1} to {end_idx}")
print("\nLines being analyzed:")
for i in range(start_idx, min(end_idx, len(lines))):
    print(f"  {i+1}: {lines[i].rstrip()}")

# Run analysis
ops = handler.analyze(lines, start_idx, end_idx)

print(f"\nFound {len(ops)} operations:")
for op in ops:
    print(f"\n  Line {op.line_number}: {op.operation.value} {op.table}")
    print(f"    Fields: {op.fields}")
    print(f"    Has sy-uname: {op.has_sy_uname}")
    print(f"    Pattern: {op.pattern}")
    print(f"    Confidence: {op.confidence}")

# Check if T15 would pass
update_ops = [op for op in ops if op.operation.value == 'UPDATE' and op.table == 'ZTABLE']
if update_ops:
    for op in update_ops:
        if op.fields and op.has_sy_uname:
            print(f"\n✓ T15 should PASS")
        else:
            print(f"\n⚠ T15 is PARTIAL - Fields: {op.fields}, Has sy-uname: {op.has_sy_uname}")
else:
    print(f"\n✗ T15 FAIL - No UPDATE ZTABLE found")