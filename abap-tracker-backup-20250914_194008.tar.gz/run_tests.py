#!/usr/bin/env python3
"""
Test runner for ABAP SY-UNAME Taint Tracker
"""

import sys
import json
from pathlib import Path
from abap_sy_uname_tracker import ABAPTaintTracker


def run_tests():
    """Run tests and validate results"""
    print("=" * 80)
    print("ABAP SY-UNAME Taint Tracker - Test Suite")
    print("=" * 80)

    # Test configuration
    root_path = "."
    test_csv = "tests/test_seeds.csv"
    output_json = "tests/test_results.json"

    # Expected results for validation
    expected_sinks = {
        "test1_direct_insert_6": ["ZTABLE_USERS"],
        "test1_direct_insert_13": ["ZAUDIT_LOG"],
        "test2_form_propagation_6": ["ZUSER_LOG", "ZUSER_MASTER"],
        "test3_function_call_7": ["ZACTIVITY_LOG", "ZUSER_MASTER"],
        "test4_complex_flow_8": ["ZTRANSACTION"],
        "test4_complex_flow_52": [],  # Dynamic table, might not be detected
    }

    # Create tracker
    print(f"\n1. Initializing tracker with root: {root_path}")
    tracker = ABAPTaintTracker(root_path, table_prefixes=['Z', 'Y'])

    # Run analysis
    print(f"\n2. Analyzing seeds from: {test_csv}")
    results = tracker.analyze(test_csv)

    # Save results
    print(f"\n3. Saving results to: {output_json}")
    tracker.save_results(results, output_json)

    # Validate results
    print("\n4. Validating results:")
    print("-" * 40)

    passed = 0
    failed = 0

    for result in results:
        test_id = result.trace_id
        expected_tables = expected_sinks.get(test_id, [])

        # Extract table names from sinks
        found_tables = [sink.table_name for sink in result.final_sinks if sink.table_name]

        # Check if expected tables are found
        success = any(table in found_tables for table in expected_tables) if expected_tables else True

        status = "✓ PASS" if success else "✗ FAIL"
        if success:
            passed += 1
        else:
            failed += 1

        print(f"  {test_id:30} {status}")
        print(f"    Expected tables: {expected_tables}")
        print(f"    Found tables:    {found_tables}")
        print(f"    Confidence:      {result.confidence}")
        print(f"    Tainted vars:    {len(result.tainted_variables)}")
        print(f"    Trace steps:     {len(result.trace_steps)}")
        print()

    # Summary
    print("=" * 80)
    print(f"Test Results: {passed} passed, {failed} failed")
    print("=" * 80)

    return failed == 0


def debug_trace(trace_id: str):
    """Debug a specific trace"""
    with open("tests/test_results.json", "r") as f:
        data = json.load(f)

    for trace in data["traces"]:
        if trace["trace_id"] == trace_id:
            print(f"\nTrace: {trace_id}")
            print("-" * 40)
            print(f"Start: {trace['start_file']}:{trace['start_line']}")
            print(f"Tainted variables: {trace['tainted_variables']}")
            print("\nTrace steps:")
            for i, step in enumerate(trace["trace_steps"], 1):
                print(f"  {i}. [{step['action']}] {step['file']}:{step['stmt_line_no']}")
                print(f"     {step['stmt_text'][:80]}")
            print("\nSinks found:")
            for sink in trace["final_sinks"]:
                print(f"  - {sink['type']} {sink['table_name']} at {sink['file']}:{sink['line']}")
            break


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "debug":
        if len(sys.argv) > 2:
            debug_trace(sys.argv[2])
        else:
            print("Usage: python run_tests.py debug <trace_id>")
    else:
        success = run_tests()
        sys.exit(0 if success else 1)