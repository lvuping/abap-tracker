#!/usr/bin/env python3
"""Fix test case line numbers to match actual ABAP patterns"""

import re

# Read the ABAP file
with open('input/all_abap_patterns.abap', 'r') as f:
    lines = f.readlines()

# Find all pattern locations
patterns = {}
current_pattern = None
start_line = None

for i, line in enumerate(lines, 1):
    # Look for pattern headers
    if '* INSERT PATTERN' in line or '* UPDATE PATTERN' in line or '* MODIFY PATTERN' in line:
        if current_pattern and start_line:
            # Save previous pattern
            patterns[current_pattern] = (start_line, i - 1)

        # Extract pattern type and number
        if 'INSERT PATTERN' in line:
            match = re.search(r'INSERT PATTERN (\d+)', line)
            if match:
                current_pattern = f"INSERT_{match.group(1)}"
                start_line = i + 2  # Skip comment line
        elif 'UPDATE PATTERN' in line:
            match = re.search(r'UPDATE PATTERN (\d+)', line)
            if match:
                current_pattern = f"UPDATE_{match.group(1)}"
                start_line = i + 2
        elif 'MODIFY PATTERN' in line:
            match = re.search(r'MODIFY PATTERN (\d+)', line)
            if match:
                current_pattern = f"MODIFY_{match.group(1)}"
                start_line = i + 2

# Save last pattern
if current_pattern and start_line:
    patterns[current_pattern] = (start_line, len(lines))

# Map test cases to patterns
test_mapping = {
    'T11': 'UPDATE_1',   # Basic UPDATE with SET
    'T12': 'UPDATE_3',   # UPDATE multiple SET fields
    'T13': 'UPDATE_4',   # UPDATE multiline SET
    'T14': 'UPDATE_5',   # UPDATE complex WHERE
    'T15': 'UPDATE_6',   # UPDATE FROM structure
    'T16': 'UPDATE_7',   # UPDATE with subquery
    'T17': 'UPDATE_8',   # UPDATE CLIENT SPECIFIED
    'T18': 'UPDATE_9',   # UPDATE with calculations
    'T19': 'UPDATE_10',  # UPDATE with CASE
    'T20': 'UPDATE_11',  # UPDATE nested parentheses

    'T21': 'MODIFY_1',   # Basic MODIFY from structure
    'T22': 'MODIFY_2',   # MODIFY FROM TABLE
    'T23': 'MODIFY_3',   # MODIFY with TRANSPORTING
    'T24': 'MODIFY_4',   # MODIFY internal table
    'T25': 'MODIFY_5',   # MODIFY WHERE condition
    'T26': 'MODIFY_6',   # MODIFY TABLE sorted
    'T27': 'MODIFY_7',   # MODIFY from internal table
    'T28': 'MODIFY_8',   # MODIFY VALUE constructor
    'T29': 'MODIFY_9',   # MODIFY inline work area
    'T30': 'MODIFY_10',  # MODIFY LOOP field symbols
}

# Print correct line numbers
print("Correct line numbers for test cases:")
print("=" * 50)

for test_id, pattern_key in test_mapping.items():
    if pattern_key in patterns:
        start, end = patterns[pattern_key]
        print(f"{test_id}: {pattern_key} -> Lines {start}-{end}")
    else:
        print(f"{test_id}: {pattern_key} -> NOT FOUND")

# Also look for specific patterns manually
print("\n" + "=" * 50)
print("Actual UPDATE statements found:")
for i, line in enumerate(lines, 1):
    if line.strip().startswith('UPDATE ') and 'SET' in line:
        # Find the end of this statement
        end_line = i
        for j in range(i, min(i+10, len(lines))):
            if lines[j].strip().endswith('.'):
                end_line = j + 1
                break
        print(f"Line {i}-{end_line}: {line.strip()[:60]}...")