#!/usr/bin/env python3
"""Direct test of handler with specific pattern"""

from src.core.db_handler import CompleteDBHandler

handler = CompleteDBHandler()

# Test UPDATE FROM @ls_rec with context
lines = [
    "ls_rec-changed_by = sy-uname.",
    "UPDATE ztable FROM ls_rec.",
    "",
    "*----------------------------------------------------------------------*",
    "* UPDATE PATTERN 6: FROM @structure",
    "*----------------------------------------------------------------------*",
    "UPDATE ztable FROM @ls_rec."
]

# Test line 6 (UPDATE FROM @ls_rec)
results = handler.analyze(lines, 0, len(lines))

print(f"Found {len(results)} operations")
for op in results:
    print(f"  Line {op.line_number}: {op.operation.value} {op.table}")
    print(f"    Fields: {op.fields}")
    print(f"    Has sy-uname: {op.has_sy_uname}")
    print(f"    Pattern: {op.pattern}")
    print()