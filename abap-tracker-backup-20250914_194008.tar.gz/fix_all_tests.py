#!/usr/bin/env python3
"""Fix all test cases to ensure they have proper context"""

# Define the correct line ranges with context for each test
test_fixes = {
    # INSERT tests
    'T01': (19, 21),  # ls_rec-created_by = sy-uname at line 20
    'T02': (36, 36),  # Direct VALUES with sy-uname
    'T03': (41, 43),  # Multiple VALUES rows
    'T04': (58, 58),  # VALUE constructor
    'T05': (63, 63),  # VALUE ztable constructor
    'T06': (48, 48),  # FROM TABLE lt_tab
    'T07': (53, 53),  # ACCEPTING DUPLICATE KEYS
    'T08': (102, 103), # Field symbol assignment
    'T09': (109, 110), # Reference assignment
    'T10': (68, 70),  # Complex VALUE

    # UPDATE tests
    'T11': (175, 175), # Basic SET
    'T12': (186, 188), # Multiple SET fields
    'T13': (193, 197), # Multiline SET
    'T14': (202, 203), # UPDATE with ls_rec context
    'T15': (202, 203), # UPDATE FROM ls_rec
    'T16': (213, 215), # CLIENT SPECIFIED
    'T17': (220, 222), # Additional UPDATE patterns
    'T18': (227, 229), # Calculations
    'T19': (234, 240), # CASE statement
    'T20': (245, 247), # Nested parentheses

    # MODIFY tests
    'T21': (316, 317), # Basic MODIFY with ls_rec
    'T22': (327, 327), # FROM TABLE lt_tab
    'T23': (326, 329), # TRANSPORTING (needs context)
    'T24': (332, 336), # Internal table
    'T25': (339, 342), # WHERE condition
    'T26': (345, 348), # TABLE sorted
    'T27': (351, 353), # From internal table
    'T28': (356, 358), # VALUE constructor
    'T29': (361, 363), # Inline work area
    'T30': (396, 398), # LOOP field symbols
}

# Print the fixes
print("Test case fixes needed:")
print("=" * 50)
for test_id, (start, end) in test_fixes.items():
    print(f'{test_id}: Lines {start}-{end}')