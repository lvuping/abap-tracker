#!/usr/bin/env python3
"""Test the final comprehensive handler"""

from src.core.final_handler import FinalDBHandler

# Test patterns that were previously PARTIAL
test_cases = [
    {
        'name': 'MODIFY with TRANSPORTING',
        'lines': [
            "ls_rec-modified_by = sy-uname.",
            "ls_rec-status = 'UPDATED'.",
            "MODIFY ztable FROM ls_rec TRANSPORTING modified_by status."
        ],
        'expected': {'operation': 'MODIFY', 'table': 'ZTABLE', 'has_syuname': True}
    },
    {
        'name': 'UPDATE FROM structure',
        'lines': [
            "ls_rec-changed_by = sy-uname.",
            "UPDATE ztable FROM ls_rec."
        ],
        'expected': {'operation': 'UPDATE', 'table': 'ZTABLE', 'has_syuname': True}
    },
    {
        'name': 'INSERT FROM TABLE',
        'lines': [
            "* Internal table lt_tab assumed to have data",
            "INSERT ztable FROM TABLE lt_tab."
        ],
        'expected': {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True}
    },
    {
        'name': 'MODIFY VALUE constructor',
        'lines': [
            "MODIFY ztable FROM VALUE #( id = '001' modified_by = sy-uname )."
        ],
        'expected': {'operation': 'MODIFY', 'table': 'ZTABLE', 'has_syuname': True}
    }
]

handler = FinalDBHandler()

print("=" * 80)
print("TESTING FINAL HANDLER")
print("=" * 80)

passed = 0
failed = 0

for test in test_cases:
    print(f"\n{test['name']}")
    print("-" * 40)

    # Analyze
    results = handler.analyze(test['lines'], 0, len(test['lines']))

    # Check results
    found = False
    for op in results:
        if (op.operation.value == test['expected']['operation'] and
            op.table == test['expected']['table'] and
            op.has_sy_uname == test['expected']['has_syuname']):
            print(f"✓ PASS - {op.operation.value} {op.table}")
            print(f"  Fields: {op.fields}")
            print(f"  Has sy-uname: {op.has_sy_uname}")
            passed += 1
            found = True
            break

    if not found:
        print(f"✗ FAIL - Expected not found")
        if results:
            for op in results:
                print(f"  Got: {op.operation.value} {op.table}, sy-uname: {op.has_sy_uname}")
        else:
            print(f"  No operations detected")
        failed += 1

print("\n" + "=" * 80)
print(f"RESULTS: {passed}/{len(test_cases)} passed")
if passed == len(test_cases):
    print("✅ All tests passed!")