#!/usr/bin/env python3
"""Grade test results by checking against expected answers"""

import csv
import json
from pathlib import Path
from typing import Dict, List, Tuple

def load_test_expectations():
    """Define what we expect to find in each test case"""
    expectations = {
        # Test cases from input/all_abap_patterns.abap
        'all_abap_patterns': {
            19: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            21: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            26: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            31: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            36: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'USER'},
            41: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'USER'},
            48: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            53: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            58: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            63: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            68: {'operation': 'INSERT', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CREATED_BY'},
            175: {'operation': 'UPDATE', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CHANGED_BY'},
            180: {'operation': 'UPDATE', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CHANGED_BY'},
            186: {'operation': 'UPDATE', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CHANGED_BY'},
            193: {'operation': 'UPDATE', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CHANGED_BY'},
            203: {'operation': 'UPDATE', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CHANGED_BY'},
            208: {'operation': 'UPDATE', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'CHANGED_BY'},
            317: {'operation': 'MODIFY', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'MODIFIED_BY'},
            322: {'operation': 'MODIFY', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'MODIFIED_BY'},
            327: {'operation': 'MODIFY', 'table': 'ZTABLE', 'has_syuname': True, 'field': 'MODIFIED_BY'},
        }
    }
    return expectations

def grade_csv_output(csv_file: str, expectations: Dict) -> Tuple[int, int, List[str]]:
    """Grade a CSV output file against expectations"""
    correct = 0
    total = 0
    errors = []

    with open(csv_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            line_num = int(row.get('Line_Number', 0))
            if line_num in expectations:
                total += 1
                expected = expectations[line_num]

                # Check if operation matches
                operations = row.get('DB_Operations', '').upper()
                if expected['operation'] in operations:
                    # Check table
                    table = row.get('Final_Table', '').upper()
                    if table == expected['table']:
                        # Check if sy-uname is detected
                        fields = row.get('Final_Fields', '')
                        tainted = row.get('Tainted_Variables', '')

                        if 'SY-UNAME' in tainted.upper() or 'SY-UNAME' in fields.upper():
                            correct += 1
                        else:
                            errors.append(f"Line {line_num}: sy-uname not detected (expected in {expected['field']})")
                    else:
                        errors.append(f"Line {line_num}: Wrong table {table} (expected {expected['table']})")
                else:
                    errors.append(f"Line {line_num}: Operation {operations} doesn't match expected {expected['operation']}")

    return correct, total, errors

def grade_test_results():
    """Grade all test results"""
    print("=" * 80)
    print("GRADING TEST RESULTS")
    print("=" * 80)

    # Get latest output files
    output_dir = Path('output')
    csv_files = sorted(output_dir.glob('analysis_*.csv'))

    if not csv_files:
        print("No output files found!")
        return

    latest_csv = csv_files[-1]
    print(f"\nGrading: {latest_csv.name}")
    print("-" * 40)

    # Load expectations
    expectations = load_test_expectations()

    # Grade the results
    correct, total, errors = grade_csv_output(latest_csv, expectations['all_abap_patterns'])

    print(f"\nResults:")
    print(f"  Correct: {correct}/{total} ({100*correct/total:.1f}%)" if total > 0 else "  No test cases found")

    if errors:
        print(f"\nErrors found:")
        for error in errors[:10]:  # Show first 10 errors
            print(f"  - {error}")
        if len(errors) > 10:
            print(f"  ... and {len(errors)-10} more errors")

    # Also check the unit test results
    print("\n" + "=" * 80)
    print("UNIT TEST GRADING")
    print("=" * 80)

    import subprocess
    result = subprocess.run(
        ['python3', 'tests/test_all_db_operations.py'],
        capture_output=True,
        text=True,
        timeout=30
    )

    # Count actual passes vs expected
    passed = result.stdout.count('✓ PASS')
    partial = result.stdout.count('⚠ PARTIAL')
    failed = result.stdout.count('✗ FAIL')
    total_tests = passed + partial + failed

    print(f"Unit Test Results:")
    print(f"  ✓ PASS: {passed}/{total_tests}")
    print(f"  ⚠ PARTIAL: {partial}/{total_tests}")
    print(f"  ✗ FAIL: {failed}/{total_tests}")
    print(f"  Success Rate: {100*(passed+partial)/total_tests:.1f}%" if total_tests > 0 else "  No tests found")

    # Show which tests are not fully passing
    if partial > 0 or failed > 0:
        print(f"\nTests needing improvement:")
        lines = result.stdout.split('\n')
        for line in lines:
            if '⚠ PARTIAL' in line or '✗ FAIL' in line:
                test_name = line.split(':')[0].replace('⚠ PARTIAL', '').replace('✗ FAIL', '').strip()
                print(f"  - {test_name}")

if __name__ == "__main__":
    grade_test_results()