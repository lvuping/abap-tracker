#!/usr/bin/env python3
"""Debug partial pass issues"""

from src.core.db_handler import CompleteDBHandler

# Test cases that are PARTIAL
test_cases = [
    # T15: UPDATE FROM structure - should detect ls_rec has sy-uname
    {
        'name': 'T15: UPDATE FROM structure',
        'lines': [
            "ls_rec-changed_by = sy-uname.",
            "UPDATE ztable FROM ls_rec."
        ],
        'expected': {'table': 'ZTABLE', 'field': 'CHANGED_BY', 'has_syuname': True}
    },
    # T21: MODIFY FROM structure
    {
        'name': 'T21: MODIFY FROM structure',
        'lines': [
            "ls_rec-modified_by = sy-uname.",
            "MODIFY ztable FROM ls_rec."
        ],
        'expected': {'table': 'ZTABLE', 'field': 'MODIFIED_BY', 'has_syuname': True}
    },
    # T22: MODIFY FROM TABLE
    {
        'name': 'T22: MODIFY FROM TABLE',
        'lines': [
            "* Assume lt_tab contains sy-uname data",
            "MODIFY ztable FROM TABLE lt_tab."
        ],
        'expected': {'table': 'ZTABLE', 'field': 'MODIFIED_BY', 'has_syuname': True}
    }
]

handler = CompleteDBHandler()

print("=" * 80)
print("DEBUGGING PARTIAL PASS ISSUES")
print("=" * 80)

for test in test_cases:
    print(f"\n{test['name']}")
    print("-" * 40)
    print("Input lines:")
    for i, line in enumerate(test['lines']):
        print(f"  {i}: {line}")

    # Analyze
    results = handler.analyze(test['lines'], 0, len(test['lines']))

    print(f"\nResults: {len(results)} operations found")
    for op in results:
        print(f"  Operation: {op.operation.value}")
        print(f"  Table: {op.table}")
        print(f"  Fields: {op.fields}")
        print(f"  Has sy-uname: {op.has_sy_uname}")
        print(f"  Pattern: {op.pattern}")

        # Check against expected
        if op.table == test['expected']['table']:
            if op.fields and op.has_sy_uname:
                print("  ✓ PASS")
            else:
                print(f"  ⚠ PARTIAL - Fields empty or sy-uname not detected")
        else:
            print(f"  ✗ FAIL - Wrong table")

print("\n" + "=" * 80)
print("ISSUE IDENTIFIED:")
print("- Handler detects the operation and table correctly")
print("- But fields are empty when using FROM structure")
print("- This is because _get_struct_fields doesn't find ls_rec in context")
print("- Even though we track ls_rec-field = sy-uname assignments")