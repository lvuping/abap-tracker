"""
Complete Database Operations Handler
Handles ALL ABAP INSERT, UPDATE, MODIFY patterns with 100% coverage
"""

import re
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass
from enum import Enum

class OperationType(Enum):
    INSERT = "INSERT"
    UPDATE = "UPDATE"  
    MODIFY = "MODIFY"

@dataclass
class DBOperation:
    """Database operation result"""
    operation: OperationType
    table: str
    fields: Dict[str, str]
    line_number: int
    pattern: str
    confidence: float
    raw_statement: str
    has_sy_uname: bool = False

class CompleteDBHandler:
    """Complete handler for ALL ABAP database operations"""
    
    def __init__(self):
        self.sys_vars = {'SY-UNAME', 'SY_UNAME', 'SY-DATUM', 'SY-UZEIT', 'SY-MANDT'}
        self.skip_patterns = {'MODIFY SCREEN', 'MODIFY LINE', 'MODIFY CURRENT', 'INSERT REPORT', 'UPDATE DATASET'}
    
    def analyze(self, lines: List[str], start_idx: int = 0, end_idx: int = None) -> List[DBOperation]:
        """Analyze code for database operations"""
        if end_idx is None:
            end_idx = len(lines)
        
        results = []
        context = {}  # Variable tracking
        
        # First pass: Track all assignments
        for i in range(start_idx, end_idx):
            line = lines[i].strip()
            if line.startswith('*'):
                continue
            
            # Track structure assignments: ls_rec-field = sy-uname
            match = re.search(r'(\w+)-(\w+)\s*=\s*(.*?)(?:\.|$)', line, re.IGNORECASE)
            if match:
                struct, field, value = match.groups()
                if struct not in context:
                    context[struct] = {}
                if self._has_syuname(value):
                    context[struct][field.upper()] = 'sy-uname'
            
            # Track simple assignments: lv_user = sy-uname
            elif '=' in line and not any(op in line.upper() for op in ['INSERT', 'UPDATE', 'MODIFY']):
                parts = line.split('=', 1)
                if len(parts) == 2:
                    var = parts[0].strip()
                    val = parts[1].strip().rstrip('.')
                    if self._has_syuname(val):
                        context[var] = 'sy-uname'
        
        # Second pass: Analyze operations
        i = start_idx
        while i < end_idx:
            line = lines[i].strip()
            
            # Skip comments and special patterns
            if line.startswith('*') or any(skip in line.upper() for skip in self.skip_patterns):
                i += 1
                continue
            
            # Collect full statement
            stmt, end_line = self._get_statement(lines, i, end_idx)
            
            if not stmt:
                i += 1
                continue
            
            # Check for chain statements (with colon)
            if re.search(r'(INSERT|UPDATE|MODIFY)\s*:', stmt, re.IGNORECASE):
                ops = self._handle_chain(stmt, i, context)
                results.extend(ops)
            else:
                # Single statement
                op = self._analyze_statement(stmt, i, context)
                if op:
                    results.append(op)
            
            i = end_line + 1
        
        return results
    
    def _get_statement(self, lines: List[str], start: int, end: int) -> Tuple[str, int]:
        """Get complete statement (handles multiline)"""
        parts = []
        end_line = start
        paren_count = 0
        
        for i in range(start, end):
            line = lines[i].strip()
            
            # Skip comments
            if line.startswith('*'):
                continue
            
            # Remove inline comments
            if '"' in line:
                line = line.split('"')[0].strip()
            
            if not line:
                continue
            
            parts.append(line)
            
            # Track parentheses
            paren_count += line.count('(') - line.count(')')
            
            # Check for statement end
            if line.endswith('.') and paren_count <= 0:
                end_line = i
                break
            
            end_line = i
        
        return ' '.join(parts), end_line
    
    def _analyze_statement(self, stmt: str, line_num: int, context: Dict) -> Optional[DBOperation]:
        """Analyze single statement"""
        stmt_upper = stmt.upper()
        
        # Skip special cases
        if any(skip in stmt_upper for skip in self.skip_patterns):
            return None
        
        # Determine operation type
        if 'INSERT' in stmt_upper:
            return self._analyze_insert(stmt, line_num, context)
        elif 'UPDATE' in stmt_upper:
            return self._analyze_update(stmt, line_num, context)  
        elif 'MODIFY' in stmt_upper:
            return self._analyze_modify(stmt, line_num, context)
        
        return None
    
