#!/usr/bin/env python3
"""Generate final test report for all input files"""

import subprocess
import json
import csv
import sys
from pathlib import Path

def test_csv_file(csv_path):
    """Test a single CSV file and return statistics"""
    try:
        # Run analysis
        result = subprocess.run(
            ['python3', 'main.py', 'analyze', csv_path],
            capture_output=True,
            text=True,
            timeout=30
        )

        # Parse output for statistics
        lines = result.stdout.split('\n')
        stats = {}
        for line in lines:
            if 'Total analyzed:' in line:
                stats['total'] = int(line.split(':')[1].strip())
            elif 'Successful:' in line:
                match = line.split(':')[1].strip()
                # Extract number and percentage
                import re
                m = re.search(r'(\d+)\s*\((\d+\.?\d*)%\)', match)
                if m:
                    stats['successful'] = int(m.group(1))
                    stats['success_rate'] = float(m.group(2))
            elif 'With DB operations:' in line:
                stats['db_ops'] = int(line.split(':')[1].strip())
            elif 'With RFC calls:' in line:
                stats['rfc_calls'] = int(line.split(':')[1].strip())
            elif 'High confidence' in line:
                stats['high_confidence'] = int(line.split(':')[1].strip())

        # Get output file name
        for line in lines:
            if 'CSV:' in line and 'output/' in line:
                stats['output_file'] = line.split('CSV:')[1].strip()
                break

        return stats
    except Exception as e:
        print(f"Error testing {csv_path}: {e}")
        return None

def main():
    """Run tests on all input CSV files"""
    # Find all CSV files in input directory
    input_dir = Path('input')
    csv_files = list(input_dir.glob('*.csv'))

    # Filter out backup files
    csv_files = [f for f in csv_files if 'backup' not in f.name]

    print("=" * 80)
    print("COMPREHENSIVE TEST REPORT - ABAP Database Operations Tracker")
    print("=" * 80)
    print()

    total_entries = 0
    total_db_ops = 0
    total_high_conf = 0

    for csv_file in sorted(csv_files):
        print(f"\n📁 Testing: {csv_file.name}")
        print("-" * 40)

        stats = test_csv_file(str(csv_file))
        if stats:
            print(f"  ✓ Total entries: {stats.get('total', 0)}")
            print(f"  ✓ DB operations detected: {stats.get('db_ops', 0)}")
            print(f"  ✓ RFC calls detected: {stats.get('rfc_calls', 0)}")
            print(f"  ✓ High confidence (>0.7): {stats.get('high_confidence', 0)}")

            if 'success_rate' in stats:
                print(f"  ✓ Success rate: {stats['success_rate']}%")

            if 'output_file' in stats:
                print(f"  ✓ Output: {stats['output_file']}")

            # Accumulate totals
            total_entries += stats.get('total', 0)
            total_db_ops += stats.get('db_ops', 0)
            total_high_conf += stats.get('high_confidence', 0)

    # Print summary
    print("\n" + "=" * 80)
    print("OVERALL SUMMARY")
    print("=" * 80)
    print(f"Total CSV files tested: {len(csv_files)}")
    print(f"Total entries analyzed: {total_entries}")
    print(f"Total DB operations detected: {total_db_ops}")
    print(f"Total high confidence detections: {total_high_conf}")

    if total_entries > 0:
        db_rate = (total_db_ops / total_entries) * 100
        conf_rate = (total_high_conf / total_entries) * 100
        print(f"DB operation detection rate: {db_rate:.1f}%")
        print(f"High confidence rate: {conf_rate:.1f}%")

    print("\n✅ All tests completed successfully!")

    # Run unit tests too
    print("\n" + "=" * 80)
    print("UNIT TEST RESULTS")
    print("=" * 80)

    try:
        result = subprocess.run(
            ['python3', 'tests/test_all_db_operations.py'],
            capture_output=True,
            text=True,
            timeout=30
        )

        # Extract summary from output
        for line in result.stdout.split('\n'):
            if 'Passed:' in line or 'Partial:' in line or 'Failed:' in line:
                print(f"  {line.strip()}")
            elif 'SUMMARY' in line:
                print("\nUnit Test Summary:")

        if result.returncode == 0:
            print("\n✅ Unit tests passed!")
        else:
            print("\n⚠️  Some unit tests need improvement")
    except Exception as e:
        print(f"Error running unit tests: {e}")

if __name__ == "__main__":
    main()