#!/usr/bin/env python3
"""
ABAP SY-UNAME Taint Tracker
Traces how SY-UNAME flows through ABAP code to database operations
"""

import re
import csv
import json
import argparse
from pathlib import Path
from typing import List, Dict, Set, Optional, Tuple, Any
from dataclasses import dataclass, field, asdict


@dataclass
class TraceStep:
    """Represents a single step in the taint propagation trace"""
    file: str
    stmt_line_no: int
    stmt_text: str
    action: str  # assign|call|db|propagate


@dataclass
class Sink:
    """Represents a final sink where tainted data reaches DB"""
    type: str  # INSERT|UPDATE|MODIFY|DELETE|RFC|METHOD|PERFORM
    table_name: Optional[str]
    sink_statement: str
    file: str
    line: int


@dataclass
class TraceResult:
    """Result of tracing from a single seed"""
    start_file: str
    start_line: int
    trace_id: str
    trace_steps: List[TraceStep] = field(default_factory=list)
    final_sinks: List[Sink] = field(default_factory=list)
    confidence: str = "low"  # high|medium|low
    tainted_variables: Set[str] = field(default_factory=set)


class ABAPStatement:
    """Represents a single ABAP statement (can span multiple lines)"""
    def __init__(self, text: str, file: str, start_line: int, end_line: int):
        self.text = text
        self.file = file
        self.start_line = start_line
        self.end_line = end_line
        self.normalized = self._normalize(text)

    def _normalize(self, text: str) -> str:
        """Normalize statement for easier matching"""
        # Remove extra whitespace
        text = ' '.join(text.split())
        # Convert to uppercase for case-insensitive matching
        return text.upper()


class ABAPIndexer:
    """Indexes ABAP codebase for efficient lookup"""

    def __init__(self, root_path: str):
        self.root_path = Path(root_path)
        self.statements: Dict[str, List[ABAPStatement]] = {}
        self.assign_statements: List[ABAPStatement] = []
        self.call_sites: List[ABAPStatement] = []
        self.db_ops: List[ABAPStatement] = []
        self.form_definitions: Dict[str, ABAPStatement] = {}
        self.function_definitions: Dict[str, ABAPStatement] = {}
        self.method_definitions: Dict[str, ABAPStatement] = {}

    def index_codebase(self):
        """Index all ABAP files in the codebase"""
        print(f"Indexing codebase at {self.root_path}")

        # Find all ABAP files
        patterns = ['**/*.abap', '**/*.src', '**/*.txt', '**/*.prog']
        abap_files = []
        for pattern in patterns:
            abap_files.extend(self.root_path.glob(pattern))

        print(f"Found {len(abap_files)} ABAP files")

        for file_path in abap_files:
            self._index_file(file_path)

        print(f"Indexed {len(self.statements)} files")
        print(f"  - {len(self.assign_statements)} assignment statements")
        print(f"  - {len(self.call_sites)} call sites")
        print(f"  - {len(self.db_ops)} DB operations")

    def _index_file(self, file_path: Path):
        """Index a single ABAP file"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
        except:
            return

        # Remove comments and join continued statements
        statements = self._extract_statements(lines, str(file_path))
        self.statements[str(file_path)] = statements

        # Categorize statements
        for stmt in statements:
            # Assignment patterns
            if self._is_assignment(stmt):
                self.assign_statements.append(stmt)

            # Call sites
            if self._is_call_site(stmt):
                self.call_sites.append(stmt)

            # DB operations
            if self._is_db_operation(stmt):
                self.db_ops.append(stmt)

            # Form definitions
            if stmt.normalized.startswith('FORM '):
                form_name = self._extract_form_name(stmt.normalized)
                if form_name:
                    self.form_definitions[form_name] = stmt

            # Function definitions
            if stmt.normalized.startswith('FUNCTION '):
                func_name = self._extract_function_name(stmt.normalized)
                if func_name:
                    self.function_definitions[func_name] = stmt

    def _extract_statements(self, lines: List[str], file_path: str) -> List[ABAPStatement]:
        """Extract logical statements from lines (handle multi-line statements)"""
        statements = []
        current_stmt = []
        start_line = 0

        for i, line in enumerate(lines):
            # Remove comments
            if line.strip().startswith('*'):
                continue

            # Remove inline comments
            if '"' in line:
                line = line[:line.index('"')]

            line = line.strip()
            if not line:
                continue

            if not current_stmt:
                start_line = i + 1

            current_stmt.append(line)

            # Check if statement ends with period
            if line.endswith('.'):
                # Complete statement
                stmt_text = ' '.join(current_stmt)
                statements.append(ABAPStatement(
                    text=stmt_text,
                    file=file_path,
                    start_line=start_line,
                    end_line=i + 1
                ))
                current_stmt = []

        return statements

    def _is_assignment(self, stmt: ABAPStatement) -> bool:
        """Check if statement is an assignment"""
        patterns = [
            r'\w+\s*=\s*',  # var = ...
            r'MOVE\s+.+\s+TO\s+',
            r'CONCATENATE\s+',
            r'SPLIT\s+',
            r'SHIFT\s+',
        ]
        return any(re.search(p, stmt.normalized) for p in patterns)

    def _is_call_site(self, stmt: ABAPStatement) -> bool:
        """Check if statement is a call site"""
        patterns = [
            r'CALL\s+FUNCTION',
            r'CALL\s+METHOD',
            r'PERFORM\s+',
            r'->\w+\s*\(',  # Method call
        ]
        return any(re.search(p, stmt.normalized) for p in patterns)

    def _is_db_operation(self, stmt: ABAPStatement) -> bool:
        """Check if statement is a database operation"""
        patterns = [
            r'INSERT\s+',
            r'UPDATE\s+',
            r'MODIFY\s+',
            r'DELETE\s+',
        ]
        return any(re.search(p, stmt.normalized) for p in patterns)

    def _extract_form_name(self, stmt_text: str) -> Optional[str]:
        """Extract form name from FORM statement"""
        match = re.match(r'FORM\s+(\w+)', stmt_text)
        return match.group(1) if match else None

    def _extract_function_name(self, stmt_text: str) -> Optional[str]:
        """Extract function name from FUNCTION statement"""
        match = re.match(r'FUNCTION\s+(\w+)', stmt_text)
        return match.group(1) if match else None


class TaintPropagator:
    """Propagates taint through ABAP code"""

    def __init__(self, indexer: ABAPIndexer, table_prefixes: List[str]):
        self.indexer = indexer
        self.table_prefixes = table_prefixes
        self.tainted_vars: Set[str] = set()
        self.trace_steps: List[TraceStep] = []
        self.sinks: List[Sink] = []

    def trace_from_seed(self, file_path: str, line_number: int, code_line: str) -> TraceResult:
        """Trace taint from a seed location"""
        # Initialize result
        result = TraceResult(
            start_file=file_path,
            start_line=line_number,
            trace_id=f"{Path(file_path).stem}_{line_number}"
        )

        # Find initial tainted variables
        self._seed_taint(file_path, line_number, code_line, result)

        # Propagate taint iteratively
        self._propagate_taint(file_path, result)

        # Find sinks
        self._find_sinks(result)

        # Calculate confidence
        result.confidence = self._calculate_confidence(result)

        return result

    def _seed_taint(self, file_path: str, line_number: int, code_line: str, result: TraceResult):
        """Seed initial tainted variables from SY-UNAME usage"""
        # Add SY-UNAME itself
        result.tainted_variables.add('SY-UNAME')

        # Check for direct assignment
        patterns = [
            (r'(\w+)\s*=\s*SY-UNAME', 'assign'),
            (r'MOVE\s+SY-UNAME\s+TO\s+(\w+)', 'move'),
            (r'DATA\s*\(\s*(\w+)\s*\)\s*=\s*SY-UNAME', 'data_assign'),
            (r'(\w+)-(\w+)\s*=\s*SY-UNAME', 'struct_assign'),  # Structure field assignment
        ]

        code_upper = code_line.upper()
        for pattern, action in patterns:
            match = re.search(pattern, code_upper)
            if match:
                if action == 'struct_assign':
                    # Both structure and field are tainted
                    struct_name = match.group(1)
                    field_name = match.group(2)
                    result.tainted_variables.add(struct_name)
                    result.tainted_variables.add(field_name)
                    result.tainted_variables.add(f"{struct_name}-{field_name}")
                else:
                    var_name = match.group(1)
                    result.tainted_variables.add(var_name)

                # Add trace step
                result.trace_steps.append(TraceStep(
                    file=file_path,
                    stmt_line_no=line_number,
                    stmt_text=code_line[:100],
                    action=action
                ))
                break

    def _propagate_taint(self, start_file: str, result: TraceResult):
        """Propagate taint through assignments and calls"""
        # Track files to process (for inter-procedural analysis)
        files_to_process = {start_file}
        processed_files = set()

        changed = True
        iteration = 0
        max_iterations = 10

        while changed and iteration < max_iterations:
            changed = False
            iteration += 1

            current_files = list(files_to_process - processed_files)

            for file_path in current_files:
                if file_path not in self.indexer.statements:
                    continue

                statements = self.indexer.statements[file_path]

                for stmt in statements:
                    # Skip if before seed line in start file
                    if stmt.file == start_file and stmt.start_line < result.start_line:
                        continue

                    # Check for taint propagation
                    if self._check_propagation(stmt, result):
                        changed = True

                    # Check for inter-procedural calls
                    new_files = self._check_interprocedural(stmt, result)
                    files_to_process.update(new_files)

                processed_files.add(file_path)

    def _check_propagation(self, stmt: ABAPStatement, result: TraceResult) -> bool:
        """Check if statement propagates taint"""
        changed = False

        # Check assignments: LHS = RHS where RHS contains tainted var
        assign_patterns = [
            (r'(\w+)\s*=\s*(.+)', 'assign'),
            (r'MOVE\s+(.+?)\s+TO\s+(\w+)', 'move'),
            (r'CONCATENATE\s+(.+?)\s+INTO\s+(\w+)', 'concatenate'),
        ]

        for pattern, action in assign_patterns:
            match = re.search(pattern, stmt.normalized)
            if match:
                if action == 'move':
                    rhs = match.group(1)
                    lhs = match.group(2)
                else:
                    lhs = match.group(1)
                    rhs = match.group(2) if len(match.groups()) > 1 else match.group(1)

                # Check if RHS contains any tainted variable
                for tainted in result.tainted_variables:
                    if tainted in rhs.upper():
                        if lhs not in result.tainted_variables:
                            result.tainted_variables.add(lhs)
                            result.trace_steps.append(TraceStep(
                                file=stmt.file,
                                stmt_line_no=stmt.start_line,
                                stmt_text=stmt.text[:100],
                                action='propagate'
                            ))
                            changed = True
                        break

        # Check function/method calls
        if 'CALL FUNCTION' in stmt.normalized or 'CALL METHOD' in stmt.normalized:
            for tainted in result.tainted_variables:
                if tainted in stmt.normalized:
                    result.trace_steps.append(TraceStep(
                        file=stmt.file,
                        stmt_line_no=stmt.start_line,
                        stmt_text=stmt.text[:100],
                        action='call'
                    ))
                    break

        return changed

    def _check_interprocedural(self, stmt: ABAPStatement, result: TraceResult) -> Set[str]:
        """Check for inter-procedural taint propagation"""
        new_files = set()

        # PERFORM call
        if 'PERFORM' in stmt.normalized:
            match = re.search(r'PERFORM\s+(\w+)', stmt.normalized)
            if match:
                form_name = match.group(1)

                # Check if any tainted var is passed
                for tainted in result.tainted_variables:
                    if tainted in stmt.normalized:
                        # Find form definition
                        if form_name in self.indexer.form_definitions:
                            form_stmt = self.indexer.form_definitions[form_name]
                            new_files.add(form_stmt.file)

                            # Extract formal parameters and mark them tainted
                            self._extract_form_params(form_stmt, stmt, result)

                            result.trace_steps.append(TraceStep(
                                file=stmt.file,
                                stmt_line_no=stmt.start_line,
                                stmt_text=f"PERFORM {form_name} with tainted params",
                                action='call'
                            ))
                        break

        # CALL FUNCTION
        elif 'CALL FUNCTION' in stmt.normalized:
            match = re.search(r"CALL\s+FUNCTION\s+'([^']+)'", stmt.normalized)
            if match:
                func_name = match.group(1)

                # Check if any tainted var is passed
                for tainted in result.tainted_variables:
                    if tainted in stmt.normalized:
                        # Check if it's a Z/Y function (likely custom)
                        if func_name.startswith(('Z', 'Y')):
                            # Find function definition if available
                            if func_name in self.indexer.function_definitions:
                                func_stmt = self.indexer.function_definitions[func_name]
                                new_files.add(func_stmt.file)

                                # Extract parameters
                                self._extract_function_params(func_stmt, stmt, result)

                            result.trace_steps.append(TraceStep(
                                file=stmt.file,
                                stmt_line_no=stmt.start_line,
                                stmt_text=f"CALL FUNCTION '{func_name}' with tainted params",
                                action='call'
                            ))
                        break

        # CALL METHOD
        elif 'CALL METHOD' in stmt.normalized or '->' in stmt.normalized:
            # Extract method name
            method_match = re.search(r'CALL\s+METHOD\s+(\w+)', stmt.normalized)
            if not method_match:
                method_match = re.search(r'(\w+)->(\w+)', stmt.normalized)

            if method_match:
                method_name = method_match.group(2) if '->' in stmt.normalized else method_match.group(1)

                # Check if any tainted var is passed
                for tainted in result.tainted_variables:
                    if tainted in stmt.normalized:
                        # Find method definition if available
                        if method_name in self.indexer.method_definitions:
                            method_stmt = self.indexer.method_definitions[method_name]
                            new_files.add(method_stmt.file)

                            result.trace_steps.append(TraceStep(
                                file=stmt.file,
                                stmt_line_no=stmt.start_line,
                                stmt_text=f"CALL METHOD {method_name} with tainted params",
                                action='call'
                            ))
                        break

        return new_files

    def _extract_form_params(self, form_def: ABAPStatement, call_stmt: ABAPStatement, result: TraceResult):
        """Extract formal parameters from FORM and map to actual parameters"""
        # Extract USING/CHANGING parameters from form definition
        match = re.search(r'FORM\s+\w+\s+(?:USING|CHANGING)\s+(.+?)\.', form_def.normalized, re.DOTALL)
        if match:
            params_text = match.group(1)
            # Extract parameter names
            param_names = re.findall(r'(\w+)(?:\s+TYPE|\s+LIKE|\s|,|$)', params_text)

            # Mark formal parameters as tainted if corresponding actual params are tainted
            for param in param_names:
                result.tainted_variables.add(param)

    def _extract_function_params(self, func_def: ABAPStatement, call_stmt: ABAPStatement, result: TraceResult):
        """Extract formal parameters from FUNCTION and map to actual parameters"""
        # Parse EXPORTING/IMPORTING/TABLES parameters
        param_patterns = [
            r'EXPORTING\s+(\w+)\s*=\s*(\w+)',
            r'IMPORTING\s+(\w+)\s*=\s*(\w+)',
            r'TABLES\s+(\w+)\s*=\s*(\w+)',
        ]

        for pattern in param_patterns:
            matches = re.findall(pattern, call_stmt.normalized)
            for formal, actual in matches:
                if actual in result.tainted_variables:
                    result.tainted_variables.add(formal)

    def _find_sinks(self, result: TraceResult):
        """Find database operation sinks"""
        # Only look for sinks in files we've processed (reachable from seed)
        processed_files = {step.file for step in result.trace_steps}
        processed_files.add(result.start_file)

        for stmt in self.indexer.db_ops:
            # Skip if not in a processed file
            if stmt.file not in processed_files:
                continue

            # Skip if before the seed line in the start file
            if stmt.file == result.start_file and stmt.start_line < result.start_line:
                continue

            # Check if statement contains tainted variables
            contains_tainted = False
            for tainted in result.tainted_variables:
                if tainted in stmt.normalized:
                    contains_tainted = True
                    break

            if not contains_tainted:
                continue

            # Extract table name and operation type
            table_name = None
            op_type = None

            # INSERT patterns
            if 'INSERT' in stmt.normalized:
                op_type = 'INSERT'
                patterns = [
                    r'INSERT\s+INTO\s+(\w+)',
                    r'INSERT\s+(\w+)',
                    r'INSERT\s+VALUE.+?INTO\s+(\w+)',
                ]
                for pattern in patterns:
                    match = re.search(pattern, stmt.normalized)
                    if match:
                        table_name = match.group(1)
                        break

            # UPDATE patterns
            elif 'UPDATE' in stmt.normalized:
                op_type = 'UPDATE'
                match = re.search(r'UPDATE\s+(\w+)', stmt.normalized)
                if match:
                    table_name = match.group(1)

            # MODIFY patterns
            elif 'MODIFY' in stmt.normalized:
                op_type = 'MODIFY'
                match = re.search(r'MODIFY\s+(\w+)', stmt.normalized)
                if match:
                    table_name = match.group(1)

            # DELETE patterns
            elif 'DELETE' in stmt.normalized:
                op_type = 'DELETE'
                match = re.search(r'DELETE\s+FROM\s+(\w+)', stmt.normalized)
                if match:
                    table_name = match.group(1)

            # Check if table matches configured prefixes
            if table_name and self._is_real_db_table(table_name):
                result.final_sinks.append(Sink(
                    type=op_type,
                    table_name=table_name,
                    sink_statement=stmt.text[:200],
                    file=stmt.file,
                    line=stmt.start_line
                ))

                # Add to trace
                result.trace_steps.append(TraceStep(
                    file=stmt.file,
                    stmt_line_no=stmt.start_line,
                    stmt_text=stmt.text[:100],
                    action='db'
                ))

    def _is_real_db_table(self, table_name: str) -> bool:
        """Check if table is a real DB table (not internal table)"""
        # Exclude internal table patterns
        internal_patterns = [r'^LT_', r'^GT_', r'^IT_', r'^CT_', r'^TT_', r'^LS_', r'^GS_']
        for pattern in internal_patterns:
            if re.match(pattern, table_name, re.IGNORECASE):
                return False

        # Check configured prefixes
        for prefix in self.table_prefixes:
            if table_name.upper().startswith(prefix.upper()):
                return True

        return False

    def _calculate_confidence(self, result: TraceResult) -> str:
        """Calculate confidence level for the trace"""
        if not result.final_sinks:
            return "low"

        # High confidence: direct use of tainted var in DB operation
        if len(result.trace_steps) <= 3 and result.final_sinks:
            return "high"

        # Medium confidence: tainted var passed through function/method
        if any(step.action == 'call' for step in result.trace_steps):
            return "medium"

        # Low confidence: dynamic table names or many propagation steps
        if len(result.trace_steps) > 10:
            return "low"

        return "medium"


class ABAPTaintTracker:
    """Main taint tracker class"""

    def __init__(self, root_path: str, table_prefixes: List[str] = None):
        self.root_path = Path(root_path)
        self.table_prefixes = table_prefixes or ['Z', 'Y']
        self.indexer = ABAPIndexer(root_path)

    def analyze(self, input_csv: str) -> List[TraceResult]:
        """Analyze CSV file and trace taint for each seed"""
        # Index codebase first
        self.indexer.index_codebase()

        # Read input CSV
        results = []
        with open(input_csv, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                file_path = row.get('file_path', '')
                line_number = int(row.get('line_number', 0))
                code_line = row.get('code_line', '')

                # Make path absolute if relative
                if not Path(file_path).is_absolute():
                    file_path = str(self.root_path / file_path)

                # If code_line not provided, read from file
                if not code_line and Path(file_path).exists():
                    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = f.readlines()
                        if 0 < line_number <= len(lines):
                            code_line = lines[line_number - 1].strip()

                # Trace from this seed
                print(f"Tracing from {Path(file_path).name}:{line_number}")
                propagator = TaintPropagator(self.indexer, self.table_prefixes)
                result = propagator.trace_from_seed(file_path, line_number, code_line)
                results.append(result)

        return results

    def save_results(self, results: List[TraceResult], output_file: str):
        """Save results to JSON or CSV"""
        output_path = Path(output_file)

        if output_path.suffix == '.json':
            # Save as JSON
            from datetime import datetime
            output_data = {
                'timestamp': datetime.now().isoformat(),
                'root_path': str(self.root_path),
                'table_prefixes': self.table_prefixes,
                'traces': [self._serialize_result(r) for r in results]
            }
            with open(output_file, 'w', encoding='utf-8') as f:
                json.dump(output_data, f, indent=2, default=str)

        elif output_path.suffix == '.csv':
            # Save as CSV
            with open(output_file, 'w', newline='', encoding='utf-8') as f:
                fieldnames = [
                    'trace_id', 'start_file', 'start_line',
                    'sink_count', 'first_sink_type', 'first_sink_table',
                    'confidence', 'tainted_var_count', 'trace_step_count'
                ]
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()

                for result in results:
                    row = {
                        'trace_id': result.trace_id,
                        'start_file': result.start_file,
                        'start_line': result.start_line,
                        'sink_count': len(result.final_sinks),
                        'first_sink_type': result.final_sinks[0].type if result.final_sinks else '',
                        'first_sink_table': result.final_sinks[0].table_name if result.final_sinks else '',
                        'confidence': result.confidence,
                        'tainted_var_count': len(result.tainted_variables),
                        'trace_step_count': len(result.trace_steps)
                    }
                    writer.writerow(row)

        print(f"Results saved to {output_file}")

    def _serialize_result(self, result: TraceResult) -> dict:
        """Serialize TraceResult to dict, handling Sets properly"""
        data = asdict(result)
        # Convert set to list for JSON serialization
        data['tainted_variables'] = list(result.tainted_variables)
        return data


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description='ABAP SY-UNAME Taint Tracker - Traces SY-UNAME flow to database operations'
    )
    parser.add_argument('--root', required=True, help='Root path of ABAP codebase')
    parser.add_argument('--input', required=True, help='Input CSV file with seeds')
    parser.add_argument('--output', default='results.json', help='Output file (JSON or CSV)')
    parser.add_argument('--table-prefixes', default='Z,Y',
                       help='Comma-separated table prefixes for real DB tables')

    args = parser.parse_args()

    # Parse table prefixes
    table_prefixes = [p.strip() for p in args.table_prefixes.split(',')]

    # Create tracker
    tracker = ABAPTaintTracker(args.root, table_prefixes)

    # Analyze
    results = tracker.analyze(args.input)

    # Save results
    tracker.save_results(results, args.output)

    # Print summary
    print(f"\nAnalysis complete:")
    print(f"  Total traces: {len(results)}")
    print(f"  Traces with sinks: {sum(1 for r in results if r.final_sinks)}")
    print(f"  High confidence: {sum(1 for r in results if r.confidence == 'high')}")
    print(f"  Medium confidence: {sum(1 for r in results if r.confidence == 'medium')}")
    print(f"  Low confidence: {sum(1 for r in results if r.confidence == 'low')}")


if __name__ == '__main__':
    main()