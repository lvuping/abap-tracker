#!/usr/bin/env python3
"""
ABAP Tracker - Simplified Command Runner
Simple interface for common commands
"""

import sys
import os
import subprocess

def show_help():
    """Show available commands"""
    print("""
ABAP Tracker - Simple Commands
==============================

Usage: python3 run.py [command] [options]

Commands:
  analyze [file]    - Analyze CSV file (default: input/default.csv)
  report           - Generate analysis report
  test [pattern]   - Run tests (optional: specific pattern)
  help            - Show this help message

Examples:
  python3 run.py analyze                    # Analyze default CSV
  python3 run.py analyze input/test.csv     # Analyze specific CSV
  python3 run.py test                       # Run all tests
  python3 run.py test I01                   # Test specific pattern
  python3 run.py report                     # Generate report
""")

def main():
    if len(sys.argv) < 2 or sys.argv[1] in ['help', '--help', '-h']:
        show_help()
        return

    command = sys.argv[1].lower()

    if command == 'analyze':
        # Run analysis
        if len(sys.argv) > 2:
            csv_file = sys.argv[2]
        else:
            csv_file = 'input/default.csv'

        print(f"🔍 Analyzing: {csv_file}")
        subprocess.run([sys.executable, 'main.py', 'analyze', csv_file])

    elif command == 'report':
        # Generate report
        print("📊 Generating report...")
        subprocess.run([sys.executable, 'main.py', 'report'])

    elif command == 'test':
        # Run tests
        if len(sys.argv) > 2:
            pattern = sys.argv[2]
            print(f"🧪 Testing pattern: {pattern}")
            subprocess.run([sys.executable, 'tests/test_ultimate_handler.py', pattern])
        else:
            print("🧪 Running all tests...")
            subprocess.run([sys.executable, 'tests/test_all_db_operations.py'])

    else:
        print(f"❌ Unknown command: {command}")
        show_help()

if __name__ == "__main__":
    main()