#!/usr/bin/env python3
"""
Validation script to verify sy-uname locations are correct
"""

import csv
import random

def validate_locations(csv_file='input/sy_uname_locations.csv', sample_size=10):
    """Validate a sample of sy-uname locations from the CSV"""

    with open(csv_file, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        entries = list(reader)

    # Sample random entries to check
    sample = random.sample(entries, min(sample_size, len(entries)))

    print(f"Validating {len(sample)} random entries from {len(entries)} total...")
    print("=" * 60)

    errors = []
    for entry in sample:
        file_path = f"input/{entry['file_path']}"
        line_num = int(entry['line_number'])

        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()

            if line_num > len(lines):
                errors.append(f"❌ {entry['file_path']}:{line_num} - Line number exceeds file length")
                continue

            line_content = lines[line_num - 1]

            # Check for sy-uname (case-insensitive)
            if 'sy-uname' in line_content.lower():
                print(f"✅ {entry['file_path']}:{line_num}")
                print(f"   Content: {line_content.strip()}")
            else:
                errors.append(f"❌ {entry['file_path']}:{line_num} - No sy-uname found")
                errors.append(f"   Line content: {line_content.strip()}")

        except Exception as e:
            errors.append(f"❌ {entry['file_path']}:{line_num} - Error: {e}")

    print("\n" + "=" * 60)
    if errors:
        print(f"Found {len(errors)} errors:")
        for error in errors:
            print(error)
    else:
        print("✅ All sampled locations validated successfully!")

    return len(errors) == 0

if __name__ == "__main__":
    success = validate_locations()
    exit(0 if success else 1)