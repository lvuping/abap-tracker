#!/usr/bin/env python3
"""Check test results against expected correct answers"""

import csv
from pathlib import Path

# Define correct answers for each line
CORRECT_ANSWERS = {
    # Line 20: ls_rec-created_by = sy-uname
    20: {'table': 'ZTABLE', 'operation': 'ASSIGN', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 21: INSERT ztable FROM ls_rec
    21: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 26: INSERT ztable FROM @ls_rec
    26: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 31: INSERT INTO ztable VALUES ls_rec
    31: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 36: INSERT INTO ztable VALUES ( '002', 'Test', sy-uname, sy-datum )
    36: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'DIRECT'},
    # Line 41: INSERT ztable VALUES ( '003', sy-uname, sy-datum ),
    41: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'DIRECT'},
    # Line 48: INSERT ztable FROM TABLE lt_tab
    48: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'FROM_TABLE'},
    # Line 53: INSERT ztable FROM TABLE lt_tab ACCEPTING DUPLICATE KEYS
    53: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'FROM_TABLE'},
    # Line 58: INSERT ztable FROM VALUE #( id = '006' created_by = sy-uname )
    58: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 63: INSERT ztable FROM VALUE ztable( id = '007' created_by = sy-uname )
    63: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 68-70: INSERT ztable FROM @( VALUE #( id = '008' created_by = sy-uname ))
    68: {'table': 'ZTABLE', 'operation': 'INSERT', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 103: <fs>-created_by = sy-uname
    103: {'table': '', 'operation': 'ASSIGN', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 110: lr_ref->created_by = sy-uname
    110: {'table': '', 'operation': 'ASSIGN', 'has_syuname': True, 'field': 'CREATED_BY'},
    # Line 175: UPDATE ztable SET changed_by = sy-uname
    175: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'CHANGED_BY'},
    # Line 180: UPDATE ztable SET changed_by = sy-uname WHERE id = '001'
    180: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'CHANGED_BY'},
    # Line 186: UPDATE ztable SET changed_by = sy-uname, changed_date = sy-datum
    186: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'CHANGED_BY'},
    # Line 193: UPDATE ztable SET ...
    193: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'CHANGED_BY'},
    # Line 202: ls_rec-changed_by = sy-uname
    202: {'table': '', 'operation': 'ASSIGN', 'has_syuname': True, 'field': 'CHANGED_BY'},
    # Line 203: UPDATE ztable FROM ls_rec
    203: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'CHANGED_BY'},
    # Line 208: UPDATE ztable FROM @ls_rec
    208: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'CHANGED_BY'},
    # Line 213: UPDATE ztable CLIENT SPECIFIED
    213: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'CHANGED_BY'},
    # Line 220: UPDATE ztable SET processor = sy-uname
    220: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'PROCESSOR'},
    # Line 227: UPDATE ztable SET approver = sy-uname
    227: {'table': 'ZTABLE', 'operation': 'UPDATE', 'has_syuname': True, 'field': 'APPROVER'},
    # Line 316: ls_rec-modified_by = sy-uname
    316: {'table': '', 'operation': 'ASSIGN', 'has_syuname': True, 'field': 'MODIFIED_BY'},
    # Line 317: MODIFY ztable FROM ls_rec
    317: {'table': 'ZTABLE', 'operation': 'MODIFY', 'has_syuname': True, 'field': 'MODIFIED_BY'},
    # Line 322: MODIFY ztable FROM @ls_rec
    322: {'table': 'ZTABLE', 'operation': 'MODIFY', 'has_syuname': True, 'field': 'MODIFIED_BY'},
    # Line 327: MODIFY ztable FROM TABLE lt_tab
    327: {'table': 'ZTABLE', 'operation': 'MODIFY', 'has_syuname': True, 'field': 'FROM_TABLE'},
    # Line 332: MODIFY ztable FROM ls_rec TRANSPORTING modified_by
    332: {'table': 'ZTABLE', 'operation': 'MODIFY', 'has_syuname': True, 'field': 'MODIFIED_BY'},
    # Line 339: MODIFY lt_records FROM ls_rec WHERE processor = 'X'
    339: {'table': 'LT_RECORDS', 'operation': 'MODIFY', 'has_syuname': False, 'field': ''},
    # Line 356: MODIFY ztable FROM VALUE #( id = '001' modified_by = sy-uname )
    356: {'table': 'ZTABLE', 'operation': 'MODIFY', 'has_syuname': True, 'field': 'MODIFIED_BY'},
    # Line 361: MODIFY ztable FROM VALUE ztable( id = '002' modified_by = sy-uname )
    361: {'table': 'ZTABLE', 'operation': 'MODIFY', 'has_syuname': True, 'field': 'MODIFIED_BY'},
    # Line 366: MODIFY ztable CLIENT SPECIFIED FROM @( VALUE #(
    366: {'table': 'ZTABLE', 'operation': 'MODIFY', 'has_syuname': True, 'field': 'MODIFIED_BY'},
    # Line 397: <fs>-modified_by = sy-uname (in LOOP)
    397: {'table': '', 'operation': 'ASSIGN', 'has_syuname': True, 'field': 'MODIFIED_BY'},
}

def grade_results():
    """Grade the analysis results"""
    # Find latest output CSV
    output_dir = Path('output')
    csv_files = sorted(output_dir.glob('analysis_*.csv'))
    if not csv_files:
        print("No output files found!")
        return

    latest_csv = csv_files[-1]
    print(f"Grading: {latest_csv.name}")
    print("=" * 80)

    correct = 0
    incorrect = 0
    details = []

    with open(latest_csv, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            line_num = int(row.get('Line_Number', 0))
            if line_num in CORRECT_ANSWERS:
                expected = CORRECT_ANSWERS[line_num]

                # Check operation
                actual_ops = row.get('DB_Operations', '').upper()
                actual_table = row.get('Final_Table', '').upper()
                actual_fields = row.get('Final_Fields', '').upper()
                tainted_vars = row.get('Tainted_Variables', '').upper()

                # Grade the result
                is_correct = True
                errors = []

                # Check if operation is detected
                if expected['operation'] != 'ASSIGN':  # Skip assignment checks
                    if expected['operation'] not in actual_ops:
                        is_correct = False
                        errors.append(f"Operation mismatch: expected {expected['operation']}, got {actual_ops}")

                    # Check table
                    if expected['table'] and actual_table != expected['table']:
                        is_correct = False
                        errors.append(f"Table mismatch: expected {expected['table']}, got {actual_table}")

                    # Check sy-uname detection
                    if expected['has_syuname']:
                        if 'SY-UNAME' not in tainted_vars and 'SY-UNAME' not in actual_fields:
                            is_correct = False
                            errors.append(f"sy-uname not detected")

                if is_correct:
                    correct += 1
                    details.append(f"✓ Line {line_num}: CORRECT")
                else:
                    incorrect += 1
                    details.append(f"✗ Line {line_num}: INCORRECT - {', '.join(errors)}")

    # Print results
    total = correct + incorrect
    print(f"\n📊 GRADING RESULTS:")
    print(f"  Correct: {correct}/{total} ({100*correct/total:.1f}%)")
    print(f"  Incorrect: {incorrect}/{total}")

    print(f"\n📝 Details:")
    for detail in details:
        print(f"  {detail}")

    # Also show which lines are completely missing
    missing = []
    for line_num in CORRECT_ANSWERS:
        found = False
        with open(latest_csv, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                if int(row.get('Line_Number', 0)) == line_num:
                    found = True
                    break
        if not found:
            missing.append(line_num)

    if missing:
        print(f"\n⚠️  Missing lines: {missing}")

if __name__ == "__main__":
    grade_results()