#!/usr/bin/env python3
"""Test runner for CALL FUNCTION patterns"""

import sys
from typing import List, Tuple, Optional
from dataclasses import dataclass

# Add src to path
sys.path.insert(0, '.')

from src.complete_db_handler import CompleteDBHandler

@dataclass
class TestPattern:
    """Test pattern definition"""
    id: str
    operation: str
    description: str
    start_line: int
    end_line: int
    expected_function: str
    should_find_syuname: bool

class CallFunctionTester:
    def __init__(self):
        self.test_file = 'test/call_function_patterns.abap'
        self.handler = CompleteDBHandler()
        self.patterns = self._define_patterns()

    def _define_patterns(self) -> List[TestPattern]:
        """Define all test patterns with line numbers"""
        patterns = [
            # CALL FUNCTION patterns
            TestPattern("CF01", "CALL_FUNCTION", "Basic with sy-uname", 17, 20, "Z_USER_PROCESS", True),
            TestPattern("CF02", "CALL_FUNCTION", "With IMPORTING", 25, 30, "Z_GET_USER_DATA", True),
            TestPattern("CF03", "CALL_FUNCTION", "With TABLES", 35, 42, "Z_PROCESS_TABLE", True),
            TestPattern("CF04", "CALL_FUNCTION", "With CHANGING", 47, 51, "Z_MODIFY_USER", True),
            TestPattern("CF05", "CALL_FUNCTION", "RFC DESTINATION", 55, 58, "Z_REMOTE_PROCESS", True),
            TestPattern("CF06", "CALL_FUNCTION", "IN BACKGROUND TASK", 63, 66, "Z_BACKGROUND_JOB", True),
            TestPattern("CF07", "CALL_FUNCTION", "STARTING NEW TASK", 73, 78, "Z_ASYNC_PROCESS", True),
            TestPattern("CF08", "CALL_FUNCTION", "IN UPDATE TASK", 81, 85, "Z_UPDATE_PROCESS", True),
            TestPattern("CF09", "CALL_FUNCTION", "With EXCEPTIONS", 89, 95, "Z_VALIDATE_USER", True),
            TestPattern("CF10", "CALL_FUNCTION", "Dynamic function", 102, 106, "Z_DYNAMIC_FUNC", True),
            TestPattern("CF11", "CALL_FUNCTION", "Variable in EXPORTING", 111, 116, "Z_PROCESS_VAR", True),
            TestPattern("CF12", "CALL_FUNCTION", "DESTINATION IN GROUP", 119, 125, "Z_PARALLEL_PROCESS", True),
            TestPattern("CF13", "CALL_FUNCTION", "Multiple EXPORTING", 128, 133, "Z_MULTI_PARAMS", True),
            TestPattern("CF14", "CALL_FUNCTION", "Complex all params", 137, 146, "Z_COMPLEX_FUNCTION", True),
            TestPattern("CF15", "CALL_FUNCTION", "Chain with comma", 155, 156, "Z_FUNC1", True),
            TestPattern("CF16", "CALL_FUNCTION", "With structures", 161, 167, "Z_STRUCT_FUNC", True),
            TestPattern("CF17", "CALL_FUNCTION", "PERFORMING callback", 170, 175, "Z_WITH_CALLBACK", True),
            TestPattern("CF18", "CALL_FUNCTION", "BAPI function", 178, 183, "BAPI_USER_CREATE", True),
            TestPattern("CF19", "CALL_FUNCTION", "Without sy-uname", 185, 188, "Z_NO_USER", False),
            TestPattern("CF20", "CALL_FUNCTION", "Nested in IF", 196, 201, "Z_CONDITIONAL", True),
        ]
        return patterns

    def load_file(self) -> List[str]:
        """Load test file"""
        with open(self.test_file, 'r', encoding='utf-8') as f:
            return f.readlines()

    def run_tests(self) -> Tuple[int, int, int]:
        """Run all tests"""
        lines = self.load_file()
        passed = 0
        failed = 0
        total = len(self.patterns)

        print(f"\n{'='*80}")
        print(f"CALL FUNCTION HANDLER TEST")
        print(f"{'='*80}\n")

        print(f"CALL FUNCTION PATTERNS")
        print("-" * 40)

        for pattern in self.patterns:
            # Analyze pattern
            ops = self.handler.analyze(lines, pattern.start_line - 1, pattern.end_line)

            # Check results
            found = False
            correct_function = False
            has_syuname = False

            for op in ops:
                if hasattr(op, 'operation') and op.operation.value == 'CALL_FUNCTION':
                    found = True
                    # Function name is stored in table field
                    if op.table == pattern.expected_function.upper():
                        correct_function = True
                    has_syuname = op.has_sy_uname if hasattr(op, 'has_sy_uname') else False
                    break

            # Check pass/fail
            if found and correct_function and pattern.should_find_syuname == has_syuname:
                status = "✓ PASS"
                passed += 1
            else:
                status = "✗ FAIL"
                failed += 1

            # Print result
            print(f"{status} {pattern.id}: {pattern.description}")
            if found:
                print(f"     Function: {pattern.expected_function}, "
                      f"SY-UNAME: {'YES' if has_syuname else 'NO'}")
            else:
                print(f"     NOT DETECTED")

        # Summary
        print(f"\n{'='*80}")
        print(f"SUMMARY")
        print(f"{'='*80}")
        print(f"Total: {total}")
        print(f"Passed: {passed} ({passed/total*100:.1f}%)")
        print(f"Failed: {failed} ({failed/total*100:.1f}%)")

        return passed, failed, total

    def run_specific_test(self, pattern_id: str):
        """Run specific test for debugging"""
        lines = self.load_file()

        for pattern in self.patterns:
            if pattern.id == pattern_id:
                print(f"\nTesting {pattern_id}: {pattern.description}")
                print(f"Lines {pattern.start_line}-{pattern.end_line}")
                print("-" * 40)

                # Show code
                for i in range(pattern.start_line - 1, min(pattern.end_line, len(lines))):
                    print(f"{i+1:4}: {lines[i]}", end='')

                print("-" * 40)

                # Analyze
                ops = self.handler.analyze(lines, pattern.start_line - 1, pattern.end_line)

                if ops:
                    for op in ops:
                        print(f"Found: {op.operation.value if hasattr(op.operation, 'value') else op.operation}")
                        print(f"Table/Function: {op.table}")
                        print(f"Has SY-UNAME: {op.has_sy_uname if hasattr(op, 'has_sy_uname') else 'N/A'}")
                        # Debug: show parameters for CALL_FUNCTION
                        if hasattr(op, 'fields') and op.fields:
                            print(f"Parameters: {op.fields}")
                else:
                    print("No operations detected")

                return

        print(f"Pattern {pattern_id} not found")

if __name__ == "__main__":
    tester = CallFunctionTester()

    if len(sys.argv) > 1:
        # Test specific pattern
        tester.run_specific_test(sys.argv[1])
    else:
        # Run all tests
        passed, failed, total = tester.run_tests()
        sys.exit(0 if failed == 0 else 1)