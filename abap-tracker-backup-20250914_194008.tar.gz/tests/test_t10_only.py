#!/usr/bin/env python3
"""
Debug T10 pattern specifically
"""

import sys
import os
import re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.complete_db_handler import CompleteDBHandler

def debug_t10():
    handler = CompleteDBHandler()

    code = [
        "* Test 10: INSERT with complex VALUE constructor",
        "INSERT zcomplex_table FROM @( VALUE #(",
        "    BASE VALUE #( id = 'CX001' type = 'STANDARD' )",
        "    ( created_by = sy-uname",
        "      created_date = sy-datum",
        "      status = 'NEW' ) ) )."
    ]

    print("Testing T10 pattern:")
    print("-" * 40)

    # Join lines to see full statement
    stmt = ' '.join(code)
    print(f"Full statement: {stmt}")
    print()

    # Test regex match
    match = re.search(r'INSERT\s+(\w+)\s+FROM\s+(?:@\s*)?\(?\s*VALUE\s+#\s*\((.*?)\)\s*\)?', stmt, re.IGNORECASE | re.DOTALL)
    if match:
        print(f"Regex matched:")
        print(f"  Table: {match.group(1)}")
        print(f"  Content: {match.group(2)}")
        print()

        # Test _parse_value_content
        content = match.group(2)
        fields = handler._parse_value_content(content)
        print(f"Parsed fields: {fields}")

        # Test _has_syuname
        has_syuname = handler._has_syuname(content)
        print(f"Has sy-uname in content: {has_syuname}")

        # Debug: find field assignments manually
        print("\nManual field search:")
        matches = re.findall(r'(\w+)\s*=\s*([^,\)]+)', content, re.IGNORECASE)
        for field, value in matches:
            print(f"  {field} = {value}")
            if 'sy-uname' in value.lower():
                print(f"    -> Contains sy-uname!")

    # Run through handler
    print("\n" + "=" * 40)
    print("Handler result:")
    results = handler.analyze(code)
    if results:
        result = results[0]
        print(f"Table: {result.table}")
        print(f"Fields: {result.fields}")
        print(f"Pattern: {result.pattern}")
        print(f"Has SY-UNAME: {result.has_sy_uname}")
    else:
        print("No operation detected")

if __name__ == "__main__":
    debug_t10()