#!/usr/bin/env python3
"""
Test only INSERT operations to identify and fix failures
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.complete_db_handler import CompleteDBHandler

def test_insert_patterns():
    """Test all INSERT patterns from comprehensive_db_ops_test.abap"""

    handler = CompleteDBHandler()

    test_cases = [
        # T01: Basic INSERT with structure (lines 16-21)
        {
            "id": "T01",
            "description": "Basic INSERT with structure",
            "code": [
                "* Test 1: Basic INSERT with structure",
                "ls_record-field1 = 'TEST001'.",
                "ls_record-created_by = sy-uname.",
                "ls_record-created_date = sy-datum.",
                "INSERT ztable FROM ls_record."
            ],
            "expected_table": "ZTABLE",
            "expected_has_sy_uname": True
        },
        # T02: INSERT with VALUES clause - single line (lines 22-24)
        {
            "id": "T02",
            "description": "INSERT with VALUES clause - single line",
            "code": [
                "* Test 2: INSERT with VALUES clause - single line",
                "INSERT INTO ztable VALUES ( '001', 'DATA', sy-uname, sy-datum )."
            ],
            "expected_table": "ZTABLE",
            "expected_has_sy_uname": True
        },
        # T04: INSERT with VALUE constructor (lines 30-35)
        {
            "id": "T04",
            "description": "INSERT with VALUE constructor",
            "code": [
                "* Test 4: INSERT with VALUE constructor - modern syntax",
                "INSERT ztable FROM @( VALUE #( id = 'B001'",
                "                               name = 'Test User'",
                "                               created_by = sy-uname",
                "                               created_on = sy-datum ) )."
            ],
            "expected_table": "ZTABLE",
            "expected_has_sy_uname": True
        },
        # T05: INSERT VALUE constructor multiline (lines 36-44)
        {
            "id": "T05",
            "description": "INSERT VALUE constructor multiline",
            "code": [
                "* Test 5: INSERT with VALUE constructor - multiline",
                "INSERT zuser_table FROM @( VALUE #(",
                "    user_id = 'U001'",
                "    username = sy-uname",
                "    action = 'LOGIN'",
                "    timestamp = sy-uzeit",
                "    client = sy-mandt",
                "    status = 'ACTIVE' ) )."
            ],
            "expected_table": "ZUSER_TABLE",
            "expected_has_sy_uname": True
        },
        # T06: INSERT FROM TABLE (lines 45-50)
        {
            "id": "T06",
            "description": "INSERT FROM TABLE",
            "code": [
                "* Test 6: INSERT FROM TABLE",
                "lt_records = VALUE #( ( id = '001' created_by = sy-uname )",
                "                     ( id = '002' created_by = sy-uname )",
                "                     ( id = '003' created_by = sy-uname ) ).",
                "INSERT ztable FROM TABLE lt_records."
            ],
            "expected_table": "ZTABLE",
            "expected_has_sy_uname": True
        },
        # T10: INSERT complex VALUE constructor (lines 65-72)
        {
            "id": "T10",
            "description": "INSERT complex VALUE constructor",
            "code": [
                "* Test 10: INSERT with complex VALUE constructor",
                "INSERT zcomplex_table FROM @( VALUE #(",
                "    BASE VALUE #( id = 'CX001' type = 'STANDARD' )",
                "    ( created_by = sy-uname",
                "      created_date = sy-datum",
                "      status = 'NEW' ) ) )."
            ],
            "expected_table": "ZCOMPLEX_TABLE",
            "expected_has_sy_uname": True
        },
        # T44: INSERT CORRESPONDING (lines 303-306)
        {
            "id": "T44",
            "description": "INSERT CORRESPONDING",
            "code": [
                "* Test 44: INSERT with CORRESPONDING",
                "DATA: ls_source TYPE zother_table.",
                "ls_source-user = sy-uname.",
                "INSERT ztable FROM CORRESPONDING #( ls_source MAPPING created_by = user )."
            ],
            "expected_table": "ZTABLE",
            "expected_has_sy_uname": True
        },
        # T47: INSERT with FILTER (lines 320-322)
        {
            "id": "T47",
            "description": "INSERT with FILTER",
            "code": [
                "* Test 47: INSERT with FILTER",
                "INSERT ztable FROM TABLE FILTER #( lt_records USING KEY primary_key",
                "                                              WHERE created_by = sy-uname )."
            ],
            "expected_table": "ZTABLE",
            "expected_has_sy_uname": True
        },
        # T50: Batch operations (lines 335-342)
        {
            "id": "T50",
            "description": "Batch operations",
            "code": [
                "* Test 50: Batch operations with sy-uname",
                "DATA: lt_batch TYPE TABLE OF ztable.",
                "DO 10 TIMES.",
                "  APPEND VALUE #( id = |BATCH{ sy-index }|",
                "                  created_by = sy-uname",
                "                  created_date = sy-datum ) TO lt_batch.",
                "ENDDO.",
                "INSERT ztable FROM TABLE lt_batch."
            ],
            "expected_table": "ZTABLE",
            "expected_has_sy_uname": True
        }
    ]

    print("=" * 80)
    print("TESTING INSERT PATTERNS - Focused on Failed Cases")
    print("=" * 80)
    print()

    passed = 0
    failed = 0

    for test in test_cases:
        print(f"Testing {test['id']}: {test['description']}")
        print("-" * 40)

        # Analyze the code
        results = handler.analyze(test['code'])

        # Check results
        if results:
            result = results[0]
            table_match = result.table.upper() == test['expected_table']
            sy_uname_match = result.has_sy_uname == test['expected_has_sy_uname']

            if table_match and sy_uname_match:
                print(f"✓ PASS")
                print(f"  Table: {result.table}")
                print(f"  Fields: {result.fields}")
                print(f"  Pattern: {result.pattern}")
                print(f"  Has SY-UNAME: {result.has_sy_uname}")
                passed += 1
            else:
                print(f"✗ FAIL - Partial match")
                print(f"  Expected Table: {test['expected_table']}, Got: {result.table}")
                print(f"  Expected SY-UNAME: {test['expected_has_sy_uname']}, Got: {result.has_sy_uname}")
                print(f"  Fields: {result.fields}")
                print(f"  Pattern: {result.pattern}")
                failed += 1
        else:
            print(f"✗ FAIL - No operation detected")
            print(f"  Expected Table: {test['expected_table']}")
            print(f"  Expected SY-UNAME: {test['expected_has_sy_uname']}")
            failed += 1

        print()

    print("=" * 80)
    print(f"SUMMARY: {passed}/{passed+failed} passed ({passed/(passed+failed)*100:.1f}%)")
    print("=" * 80)

    return passed, failed

if __name__ == "__main__":
    passed, failed = test_insert_patterns()
    sys.exit(0 if failed == 0 else 1)