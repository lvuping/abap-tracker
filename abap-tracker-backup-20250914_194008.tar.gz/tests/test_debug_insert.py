#!/usr/bin/env python3
"""
Debug specific INSERT patterns
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.complete_db_handler import CompleteDBHandler

def test_specific_patterns():
    """Test specific failing patterns"""

    handler = CompleteDBHandler()

    # T10: INSERT complex VALUE constructor with BASE
    print("=" * 80)
    print("T10: INSERT complex VALUE constructor with BASE")
    print("=" * 80)
    code = [
        "* Test 10: INSERT with complex VALUE constructor",
        "INSERT zcomplex_table FROM @( VALUE #(",
        "    BASE VALUE #( id = 'CX001' type = 'STANDARD' )",
        "    ( created_by = sy-uname",
        "      created_date = sy-datum",
        "      status = 'NEW' ) ) )."
    ]

    print("Code:")
    for line in code:
        print(f"  {line}")
    print()

    results = handler.analyze(code)
    if results:
        result = results[0]
        print(f"Result: Table={result.table}, Pattern={result.pattern}")
        print(f"Fields: {result.fields}")
        print(f"Has SY-UNAME: {result.has_sy_uname}")
        print(f"Raw statement: {result.raw_statement}")
    else:
        print("No operation detected")

    print()
    print("=" * 80)
    print("T47: INSERT with FILTER")
    print("=" * 80)
    code = [
        "* Test 47: INSERT with FILTER",
        "INSERT ztable FROM TABLE FILTER #( lt_records USING KEY primary_key",
        "                                              WHERE created_by = sy-uname )."
    ]

    print("Code:")
    for line in code:
        print(f"  {line}")
    print()

    results = handler.analyze(code)
    if results:
        result = results[0]
        print(f"Result: Table={result.table}, Pattern={result.pattern}")
        print(f"Fields: {result.fields}")
        print(f"Has SY-UNAME: {result.has_sy_uname}")
        print(f"Raw statement: {result.raw_statement}")
    else:
        print("No operation detected")

    print()
    print("=" * 80)
    print("T50: Batch operations")
    print("=" * 80)
    code = [
        "* Test 50: Batch operations with sy-uname",
        "DATA: lt_batch TYPE TABLE OF ztable.",
        "DO 10 TIMES.",
        "  APPEND VALUE #( id = |BATCH{ sy-index }|",
        "                  created_by = sy-uname",
        "                  created_date = sy-datum ) TO lt_batch.",
        "ENDDO.",
        "INSERT ztable FROM TABLE lt_batch."
    ]

    print("Code:")
    for line in code:
        print(f"  {line}")
    print()

    results = handler.analyze(code)
    if results:
        result = results[0]
        print(f"Result: Table={result.table}, Pattern={result.pattern}")
        print(f"Fields: {result.fields}")
        print(f"Has SY-UNAME: {result.has_sy_uname}")
        print(f"Raw statement: {result.raw_statement}")
        print()
        print("Context tracking:")
        # Test the context tracking manually
        context = {}
        for i, line in enumerate(code):
            if 'APPEND' in line.upper() and 'sy-uname' in line.lower():
                import re
                match = re.search(r'TO\s+(\w+)', line, re.IGNORECASE)
                if match:
                    print(f"  Line {i}: Found APPEND with sy-uname to {match.group(1)}")
    else:
        print("No operation detected")

if __name__ == "__main__":
    test_specific_patterns()