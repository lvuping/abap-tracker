#!/usr/bin/env python3
"""
Migration script to scan all ABAP files and find exact sy-uname locations
Creates a new accurate sy_uname_locations.csv file
"""

import os
import re
import csv
from datetime import datetime

def find_sy_uname_in_file(filepath):
    """Find all occurrences of sy-uname in an ABAP file"""
    locations = []

    # Patterns to search for sy-uname (case-insensitive)
    patterns = [
        r'\bsy-uname\b',
        r'\bsy-UNAME\b',
        r'\bSY-UNAME\b',
        r'\bSY-uname\b'
    ]

    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()

        for line_num, line in enumerate(lines, 1):
            for pattern in patterns:
                if re.search(pattern, line, re.IGNORECASE):
                    # Skip comment lines
                    stripped = line.strip()
                    if not stripped.startswith('*') and not stripped.startswith('"'):
                        locations.append(line_num)
                        break  # Found in this line, no need to check other patterns

    except Exception as e:
        print(f"Error reading {filepath}: {e}")

    return locations

def scan_input_folder(input_dir='input'):
    """Scan all ABAP files in input folder for sy-uname occurrences"""
    results = []
    migration_status = []

    # Get all .abap files
    abap_files = [f for f in os.listdir(input_dir) if f.endswith('.abap')]
    abap_files.sort()

    print(f"Found {len(abap_files)} ABAP files to scan")
    migration_status.append(f"[{datetime.now()}] Starting migration scan")
    migration_status.append(f"[{datetime.now()}] Found {len(abap_files)} ABAP files")

    id_counter = 1
    for filename in abap_files:
        filepath = os.path.join(input_dir, filename)
        print(f"Scanning {filename}...")

        locations = find_sy_uname_in_file(filepath)

        if locations:
            print(f"  Found sy-uname at lines: {locations}")
            migration_status.append(f"[{datetime.now()}] {filename}: Found {len(locations)} occurrences at lines {locations}")
            for line_num in locations:
                results.append({
                    'id': id_counter,
                    'file_path': filename,
                    'line_number': line_num
                })
                id_counter += 1
        else:
            print(f"  No sy-uname found")
            migration_status.append(f"[{datetime.now()}] {filename}: No sy-uname found")

    migration_status.append(f"[{datetime.now()}] Total occurrences found: {len(results)}")
    return results, migration_status

def write_csv(results, output_file='input/sy_uname_locations.csv'):
    """Write results to CSV file"""
    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['id', 'file_path', 'line_number'])
        writer.writeheader()
        writer.writerows(results)
    print(f"\nWritten {len(results)} entries to {output_file}")

def write_migration_status(status_lines, status_file='migration_status.txt'):
    """Write migration status to tracking file"""
    with open(status_file, 'w', encoding='utf-8') as f:
        f.write("SY-UNAME LOCATION MIGRATION STATUS\n")
        f.write("=" * 50 + "\n\n")
        for line in status_lines:
            f.write(line + "\n")
        f.write("\n" + "=" * 50 + "\n")
        f.write(f"Migration completed at {datetime.now()}\n")
    print(f"Migration status written to {status_file}")

if __name__ == "__main__":
    print("Starting sy-uname location migration...")
    print("=" * 50)

    # Check if old file exists
    old_file = 'input/sy_uname_locations.csv'
    if os.path.exists(old_file):
        print(f"Old file exists: {old_file}")
        # Backup old file
        backup_name = f'input/sy_uname_locations_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        os.rename(old_file, backup_name)
        print(f"Backed up to: {backup_name}")

    # Scan and create new file
    results, migration_status = scan_input_folder()

    if results:
        write_csv(results)
        write_migration_status(migration_status)
        print("\nMigration completed successfully!")
        print(f"Total sy-uname occurrences found: {len(results)}")
    else:
        print("\nNo sy-uname occurrences found in any files!")